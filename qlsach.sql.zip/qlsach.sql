-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 25, 2023 at 04:31 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qlsach`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `CompID` tinyint(11) NOT NULL auto_increment,
  `CompName` varchar(50) collate utf8_unicode_ci NOT NULL,
  `Tel` varchar(50) collate utf8_unicode_ci NOT NULL,
  `Address` varchar(200) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`CompID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`CompID`, `CompName`, `Tel`, `Address`) VALUES
(1, 'SGK Lop 8', '024.38220801', 'Số 81 Trần Hưng Đạo, Hoàn Kiếm, Hà Nội'),
(2, 'SGK Lop 9', '024.38220801', 'Số 81 Trần Hưng Đạo, Hoàn Kiếm, Hà Nội'),
(3, 'SGK Lop 10', '024.38220801', 'Số 81 Trần Hưng Đạo, Hoàn Kiếm, Hà Nội'),
(4, 'SGK Lop 11', '024.38220801', 'Số 81 Trần Hưng Đạo, Hoàn Kiếm, Hà Nội'),
(5, 'SGK Lop 12', '024.38220801', 'Số 81 Trần Hưng Đạo, Hoàn Kiếm, Hà Nội');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ProdID` tinyint(4) NOT NULL auto_increment,
  `ProdName` varchar(50) collate utf8_unicode_ci NOT NULL,
  `ProdPrice` double NOT NULL,
  `ProdImage` varchar(100) collate utf8_unicode_ci NOT NULL,
  `ProdDescription` varchar(50) collate utf8_unicode_ci default NULL,
  `CompID` tinyint(4) NOT NULL,
  PRIMARY KEY  (`ProdID`),
  KEY `CompID` (`CompID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=49 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ProdID`, `ProdName`, `ProdPrice`, `ProdImage`, `ProdDescription`, `CompID`) VALUES
(1, 'Sách Toán 8', 32000, 'sach-giao-khoa-toan-8.jpg', 'sach toan lop 8', 1),
(2, 'Sách Ngữ Văn 8', 350000, 'sach-giao-khoa-ngu-van-lop-8.jpg', 'Sach ngu van lop 8', 1),
(3, 'Sách Lịch Sử 8', 26000, 'sach-giao-khoa-lich-su-lop-8.jpg', 'sach lich su lop 8', 1),
(4, 'Sách Vật Lí 8', 30000, 'sach-vat-li-lop8.jpg', 'sach vat li lop 8', 1),
(5, 'Sách Hóa Học 8', 25000, 'sach-giao-khoa-hoa-hoc-lop-8.jpg', 'sach hoa hoc lop 8', 1),
(6, 'Sách Toán 9', 25000, 'sach-giao-khoa-toan-lop-9.jpg', 'sach toan lop 9', 2),
(7, 'Sách Ngữ Văn 9', 24000, 'sach-ngu-van-lop9.jpg', 'Sach ngu van lop 9', 2),
(8, 'Sách Lịch Sử 9', 26000, 'sach-lich-su-lop9.jpg', 'sach lich su lop 9', 2),
(9, 'Sách Hóa Học 9', 30000, 'sach-giao-khoa-hoa-hoc-lop-9.jpg', 'sach hoa hoc lop 9', 2),
(10, 'Sách Vật Lí 9', 32000, 'sach-vat-li-lop9.jpg', 'sach vat li lop 9', 2),
(11, 'Sách Toán Đại Số 10', 20000, 'sach-giao-khoa-dai-so-lop-10.jpg', 'sach toan dai so lop 10', 3),
(12, 'Sách Ngữ Văn 10', 32000, 'Sach-giao-khoa-ngu-van-10.jpg', 'sach ngu van lop 10', 3),
(13, 'Sách Lịch Sử 10', 350000, 'sach-lich-su-lop10.jpg', 'sach lich su lop 10', 3),
(14, 'Sách Vật Lí 10', 33000, 'sach-giao-khoa-vat-li-lop-10.jpg', 'sach vat li lop 10', 3),
(15, 'Sách Hóa Học 10', 44000, 'sach-giao-khoa-hoa-hoc-lop-10.jpg', 'sach hoa hoc lop 10', 3),
(16, 'Sách Toán Đại Số 11', 20000, 'sach-giao-khoa-dai-so-va-giai-tich-11-co-ban.jpg', 'sach dai so lop 11', 4),
(17, 'Sách Ngữ Văn 11', 37000, 'Ngu-Van-11-Tap-1.jpg', 'sach ngu van lop 11', 4),
(18, 'Sách Lịch Sử 11', 33000, 'sach-giao-khoa-lich-su-11.jpg', 'sach lich su lop 11', 4),
(19, 'Sách Vật Lí 11', 31000, 'sach-vat-li-lop11.jpg', 'sach vat li lop 11', 4),
(20, 'Sach Hoa Hoc 11', 22000, 'sach-giao-khoa-hoa-hoc-lop-11.jpg', 'sach hoa hoc lop 11', 4),
(21, 'Sách Toán Đại Số 12', 34000, 'sach-dai-so-lop12.jpg', 'sach dai so lop 12', 5),
(22, 'Sách Ngữ Văn 12', 40000, 'sach-ngu-van-lop12.jpg', 'sach ngu van lop 12', 5),
(23, 'Sách Lịch Sử 12', 29000, 'sach-lich-su-lop12.jpg', 'sach lich su lop 12', 5),
(24, 'Sách Vật Lí 12', 40000, 'sach-vat-li-lop-12.jpg', 'sach vat li lop 12', 5),
(25, 'Sách Hóa Học 12', 32000, 'sach-hoa-hoc-lop12.jpg', 'sach hoa hoc lop 12', 5);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`CompID`) REFERENCES `company` (`CompID`) ON DELETE CASCADE ON UPDATE CASCADE;
